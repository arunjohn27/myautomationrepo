# =====================================================================================
#    Filename   :  TestData_Web.py
#
#    Description:  This file contains all the test data
#
#    Version    :  1.0
#    Created    :  25/01/2022
#    Compiler   :  python
#    Author     :  Arun John
#    Company    :
#
#    Revision History:
#
# =====================================================================================

text = u"Selenium Online Trainings"