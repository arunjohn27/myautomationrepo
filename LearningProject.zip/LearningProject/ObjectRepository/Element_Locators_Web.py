# =====================================================================================
#    Filename   :  Element_Locators_Web.py
#
#    Description:  This file contains all the locator values in the web page
#
#    Version    :  1.0
#    Created    :  25/01/2022
#    Compiler   :  python
#    Author     :  Arun John
#    Company    :
#
#    Revision History:
#
# =====================================================================================

header = '/html/body/header/nav/div/div/div[3]/div/div[1]/ul/li[1]/a'