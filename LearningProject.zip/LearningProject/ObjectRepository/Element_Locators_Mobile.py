# =====================================================================================
#    Filename   :  Element_Locators_Mobile.py
#
#    Description:  This file contains all the locator values in the mobile application
#
#    Version    :  1.0
#    Created    :  25/01/2022
#    Compiler   :  python
#    Author     :  Arun John
#    Company    :
#
#    Revision History:
#
# =====================================================================================

